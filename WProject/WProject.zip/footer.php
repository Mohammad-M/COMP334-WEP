<!-- Footer -->
<footer class="container padding-64 center opacity light-grey xlarge">
    <i class="fa fa-facebook-official hover-opacity"></i>
    <i class="fa fa-instagram hover-opacity"></i>
    <i class="fa fa-snapchat hover-opacity"></i>
    <i class="fa fa-pinterest-p hover-opacity"></i>
    <i class="fa fa-twitter hover-opacity"></i>
    <i class="fa fa-linkedin hover-opacity"></i>
    <p class="medium">Created by: <br> Maryam Shaheen #1140427 <br> Mohammad Mohammad #1141648 <br> Wesam Hatem #1131362</p>
</footer>


</body>
</html>