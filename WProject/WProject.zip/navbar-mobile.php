<!-- Navbar on small screens -->
<div id="navDemo" class="bar-block black hide hide-large hide-medium top" style="margin-top:46px">
    <a href="#band" class="bar-item button padding-large">BAND</a>
    <a href="#tour" class="bar-item button padding-large">TOUR</a>
    <a href="#contact" class="bar-item button padding-large">CONTACT</a>
    <a href="#" class="bar-item button padding-large">MERCH</a>
</div>