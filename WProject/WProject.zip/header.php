<head>
<title>Latin Patriarchate Schools</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    body {font-family: "Lato", sans-serif }
	
	input, select, textarea {
	font-size: 150%;
	}
</style>
<script type="text/javascript" src="validate.js"></script>
</head>

<div class="top">
    <div class="bar black card">
        <a class="bar-item button padding-large hide-medium hide-large right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
        <a href="main.php" class="bar-item button padding-large">HOME</a>
        <a href="main.php#band" class="bar-item button padding-large hide-small">ABOUT US</a>
        <a href="main.php#tour" class="bar-item button padding-large hide-small">SERVICES</a>
        <a href="main.php#contact" class="bar-item button padding-large hide-small">CONTACT</a>
        <div class="dropdown-hover hide-small">
            <button class="padding-large button" title="More">SCHOOLS <i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content bar-block card-4">
                <a href="#" class="bar-item button">Birzeit</a>
                <a href="#" class="bar-item button">Beit Sahour</a>
                <a href="#" class="bar-item button">Gaza</a>
            </div>
        </div>
		<a href="login.php" class="bar-item button padding-large hide-small right">LogIn</a>
        <a href="javascript:void(0)" class="padding-large hover-red hide-small right"><i class="fa fa-search"></i></a>
    </div>
</div>