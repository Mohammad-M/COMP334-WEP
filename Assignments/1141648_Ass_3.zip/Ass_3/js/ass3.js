function blure() {
    var vars = document.getElementsByClassName("hilightable");
    for (var i = 0; i < vars.length; i++) {
        vars[i].onfocus = function () {
            this.classList.add("highlight");
        }
        vars[i].onblur = function () {
            this.classList.remove("highlight");
        }
    }
};
function submits(event) {
    var handle = true;
    var vars = document.getElementsByClassName("required");
    for (var i = 0; i < vars.length; i++) {
        console.log(vars[i].value);
        if (vars[i].value == "") {
            vars[i].classList.add("error");
			
            handle = false;
        }
		
		else if(vars[i].checked){
			return false;
		}
		else{
			 vars[i].classList.remove("error");
        }
		
    }
    return handle;
	event.preventDefault();
};
function myFunction(){
	var vars = document.getElementsByClassName("required");
	 
	vars[i].classList.remove("error");
}